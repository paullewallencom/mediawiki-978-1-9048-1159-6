<?php
// This file exists to ensure that base classes are preloaded before
// haunting.php is compiled


require_once('includes/SkinTemplate.php');
?>